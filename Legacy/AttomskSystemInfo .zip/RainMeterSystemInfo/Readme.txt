These are modified elements of the mii system skin 2 by abu46 on diviantart.  I do not claim to ownership of this skin, only the modification of it.

The original mii system skin 2 can be found at: 
http://abu46.deviantart.com/art/mii-system-skin-2-206965499

You do not need to install the entire mii system skin 2 to use these customized pieces of the skin.

----------------------------------------------

This skin requires you to have MSI afterburner and Coretemp installed in your system and running in the background at all times.  It is recommended to have both programs start with windows.

For MSI Afterburner, you must have the following enabled in the Settings->Monitoring menu:
GPU temperature
GPU usage
Fan speed
Core clock
Memory clock
Memory Usage
Framerate
GPU Voltage

----------------------------------------------

Put the "custom mii system skin 2" folder into C:\Documents\Rainmeter\Skins\


Put the "MSIAfterburner.dll" into C:\Program Files\Rainmeter\Plugins\

-----------------------------------------------

This customization was made by http://www.reddit.com/user/Attomsk